import React from "react";

function Order() {
  return <div>Order</div>;
}

export default Order;
